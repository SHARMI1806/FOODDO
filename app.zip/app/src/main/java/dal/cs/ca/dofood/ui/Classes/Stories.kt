package dal.cs.ca.dofood.ui.Classes

class Stories {
    var name:String?=null
    var story:String?=null
    var image:Int?=null
    constructor(name:String, story:String, image:Int){
        this.name=name
        this.story=story
        this.image=image
    }
}
